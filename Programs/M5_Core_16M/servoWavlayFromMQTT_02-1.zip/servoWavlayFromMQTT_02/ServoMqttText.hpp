#ifndef SERVOMQTTTEXT_HPP
#define SERVOMQTTTEXT_HPP

#include <Arduino.h>

#include "ServoXY.hpp"

// Minimal-heap MQTT text command handler for ServoXY.
//
// Payload format (ASCII, whitespace separated):
//   move <x> <y> <ms>
//   stop
//   home <ms>
//   speed <degps_x> <degps_y>
//   pulse <min_us_x> <max_us_x> <min_us_y> <max_us_y>
//
// Design goals:
// - No JSON parsing (avoid dynamic allocations)
// - No payload copying (parses directly on (payload,len))

class ServoMqttText {
public:
  explicit ServoMqttText(ServoXY& servo) : servo_(servo) {}

  // Returns true if the command was recognized and applied.
  bool handle(const char* topic, uint8_t* payload, unsigned int len);

private:
  ServoXY& servo_;

  static bool isSpace_(char c);
  static const char* skipSpaces_(const char* p, const char* end);
  static bool readWordEq_(const char*& p, const char* end, const char* word);
  static bool readInt_(const char*& p, const char* end, int32_t& out);
  static bool readUInt_(const char*& p, const char* end, uint32_t& out);
};

#endif
